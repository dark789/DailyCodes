#-*- coding:utf-8 -*-
import os
import wx
import pyautogui
import time
import datetime
class fra(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None, -1, title="PCR Auto-Print System V1.1",size=(800,800))
        panel=wx.Panel(self)
        wx.StaticText(panel,id=-1,pos=(50,30),label="Input List Name")
        self.savetest=wx.Button(panel,-1,label="Save",pos=(350,15),size=(100,40))
        self.savetest.Bind(wx.EVT_BUTTON,self.evtsave)
        self.testid=[]
        tempath=os.path.dirname(os.path.abspath(__file__)) + r"\data\tem\tem.txt"
        temtxt=open(tempath,"r")
        linedata=temtxt.readlines()
        ordata=[]
        temtitle=""
        for i in linedata:
            if "listname::" in i:
                temtitle=i[10:].strip("\n")
            else:
                ordata.append(i.strip("\n"))
        temtxt.close()
        self.testname=wx.TextCtrl(panel,id=-1,pos=(150,30),size=(100,20),value=temtitle)
        for i in range(12):
            for j in range(8):
                if 8*i+j<=len(ordata)-1:
                    temid=wx.NewId()
                    self.testid.append(temid)
                    temtxtctrl=wx.TextCtrl(panel,id=temid,pos=(50+60*j,75+30*i),size=(60,20),value=ordata[8*i+j])
                    temtxtctrl.Bind(wx.EVT_TEXT,self.evttextchange)
                else:
                    temid=wx.NewId()
                    self.testid.append(temid)
                    temtxtctrl=wx.TextCtrl(panel,id=temid,pos=(50+60*j,75+30*i),size=(60,20))
                    temtxtctrl.Bind(wx.EVT_TEXT,self.evttextchange)
        for i in range(8):
            wx.StaticText(panel,id=-1,pos=(80+60*i,55),label=chr(65+i))
        for i in range(12):
            wx.StaticText(panel,id=-1,pos=(35,75+30*i),label=str(i+1))
        self.qc=wx.Button(panel,-1,label="QC Input",pos=(550,55),size=(100,40))
        self.qc.Bind(wx.EVT_BUTTON,self.evtqc)
        self.butautofill=wx.Button(panel,-1,label="Auto-Fill",pos=(550,100),size=(100,40))
        self.butautofill.Bind(wx.EVT_BUTTON,self.evtautofill)
        self.bollhaveautofilled=False
        self.clear=wx.Button(panel,-1,label="Clear",pos=(550,145),size=(100,40))
        self.clear.Bind(wx.EVT_BUTTON,self.evtclear)
        self.autotype=wx.Button(panel,-1,label="Auto-Print",pos=(550,190),size=(100,40))
        self.autotype.Bind(wx.EVT_BUTTON,self.evtautotype)
        wx.StaticText(panel,id=-1,pos=(550,245),label="Print Interval:")
        self.tclinterval=wx.TextCtrl(panel,id=-1,value="0.1",pos=(600,245),size=(30,20))
        self.typerangeL=wx.TextCtrl(panel,id=-1,pos=(650,190),size=(25,25),value="1")
        self.typerangeR=wx.TextCtrl(panel,id=-1,pos=(690,190),size=(25,25),value="96")
        wx.StaticText(panel,id=-1,pos=(680,190),label="-")
        self.postxtpath=os.path.dirname(os.path.abspath(__file__)) + "\\setting\\possetting.txt"
        posfile=open(self.postxtpath,"r")
        linedata=posfile.readlines()
        posfile.close()
        self.posdata=[]
        for i in linedata:
            self.posdata.append(i.strip("\n"))
        self.clickid=[]
        self.clickposid=[]
        for i in range(6):
            self.temid=wx.NewId()
            self.clickid.append(self.temid)
            self.tembutton=wx.Button(panel,id=self.temid,label="C" + str(i+1),pos=(50,450+50*i),size=(100,40))
            self.Bind(wx.EVT_BUTTON,self.getpos,self.tembutton)
            self.temid=wx.NewId()
            self.clickposid.append(self.temid)
            self.temclickctrl=wx.TextCtrl(panel,id=self.temid,value=self.posdata[i],pos=(150,450+50*i),size=(100,40),style=wx.TE_READONLY)
        self.saveposbut=wx.Button(panel,-1,label="Save Position",pos=(350,500),size=(100,40))
        self.saveposbut.Bind(wx.EVT_BUTTON,self.evtsavepos)
        self.butautoclick=wx.Button(panel,-1,label="Auto-Click",pos=(350,550),size=(100,40))
        self.butautoclick.Bind(wx.EVT_BUTTON,self.evtautoclick)
        self.butonekeyinput=wx.Button(panel,-1,label="One-Key Input",pos=(350,595),size=(100,40))
        self.butonekeyinput.Bind(wx.EVT_BUTTON,self.evtonekeyinput)
    def evtqc(self,evt):
        wx.Window.FindWindowById(self.testid[0]).SetValue("NC1")
        wx.Window.FindWindowById(self.testid[1]).SetValue("NC2")
        wx.Window.FindWindowById(self.testid[2]).SetValue("NC3")
        wx.Window.FindWindowById(self.testid[3]).SetValue("PC")
        wx.Window.FindWindowById(self.testid[95]).SetValue("BK")
    def evtautofill(self,evt):
        if self.testname.GetValue().strip("\n")!="":
            for i in range(1,95):
                if wx.Window.FindWindowById(self.testid[i]).GetValue() == "":
                    temstr=wx.Window.FindWindowById(self.testid[i-1]).GetValue()
                    newstr=""
                    laterstr=""
                    strblock=[]
                    if len(temstr)<=1:
                        if temstr.isdigit():
                            newstr=str(int(temstr)+1)
                            wx.Window.FindWindowById(self.testid[i]).SetValue(newstr)
                        else:
                            wx.Window.FindWindowById(self.testid[i]).SetValue(temstr)
                    else:
                        temtemstr=temstr[0]
                        for j in range(1,len(temstr)):
                            if temstr[j].isdigit() == temstr[j-1].isdigit():
                                temtemstr=temtemstr+temstr[j]
                            else:
                                strblock.append(temtemstr)
                                temtemstr=temstr[j]
                        strblock.append(temtemstr)
                        newstr=""
                        for j in strblock:
                            if j.isdigit():
                                newstr=newstr+str(int(j)+1)
                            else:
                                newstr=newstr+j
                        wx.Window.FindWindowById(self.testid[i]).SetValue(newstr)            
            temdata=[]
            for i in range(96):
                temdata.append(wx.Window.FindWindowById(self.testid[i]).GetValue())
            tempath=os.path.dirname(os.path.abspath(__file__)) + r"\data\tem\tem.txt"
            temtxt=open(tempath,"w")
            temtxt.write("listname::" + self.testname.GetValue()+"\n")
            for i in temdata:
                temtxt.write(i+"\n")
            temtxt.close()
            uliquedata=[temdata[0]]
            samedata=0
            for i in temdata[1:]:
                if samedata==1:
                    break
                for j in uliquedata:
                    if i == j and i!="" :
                        samedata=1
                        wx.MessageDialog(None,'Duplicate sample name:' + i,"Warning",wx.OK).ShowModal()
                        break
                if samedata==0:
                    uliquedata.append(i)
            if samedata==0:
                self.bollhaveautofilled=True
            filename=self.testname.GetValue() 
            filedir=os.path.dirname(os.path.abspath(__file__)) + "\\data\\"
            filetxt=open(filedir+filename+".txt","w")
            filetxt.write("listname::" + filename+"\n")
            for i in range(96):
                filetxt.write(wx.Window.FindWindowById(self.testid[i]).GetValue() + "\n")
            filetxt.close()
        else:
            wx.MessageDialog(None,"Listname cannot be empty","Warning",wx.OK).ShowModal()
    def evtclear(self,evt):
        for i in self.testid:
            wx.Window.FindWindowById(i).SetValue("")
        self.testname.SetValue("")
    def evtautotype(self,evt):
        if self.bollhaveautofilled==True:
            time.sleep(3)
            for i in range(int(self.typerangeL.GetValue())-1,int(self.typerangeR.GetValue())):
                pyautogui.typewrite(message=wx.Window.FindWindowById(self.testid[i]).GetValue(),interval=0.01)
                pyautogui.press('down')
                time.sleep(float(self.tclinterval.GetValue()))
        else:
            wx.MessageDialog(None,"Please 'Auto-Fullfill' First","Warning",wx.OK).ShowModal()
    def evtsave(self,evt):
        for i in range(1,95):
            if wx.Window.FindWindowById(self.testid[i]).GetValue() == "":
                temstr=wx.Window.FindWindowById(self.testid[i-1]).GetValue()
                newstr=""
                laterstr=""
                strblock=[]
                if len(temstr)<=1:
                    if temstr.isdigit():
                        newstr=str(int(temstr)+1)
                        wx.Window.FindWindowById(self.testid[i]).SetValue(newstr)
                    else:
                        wx.Window.FindWindowById(self.testid[i]).SetValue(temstr)
                else:
                    temtemstr=temstr[0]
                    for j in range(1,len(temstr)):
                        if temstr[j].isdigit() == temstr[j-1].isdigit():
                            temtemstr=temtemstr+temstr[j]
                        else:
                            strblock.append(temtemstr)
                            temtemstr=temstr[j]
                    strblock.append(temtemstr)
                    newstr=""
                    for j in strblock:
                        if j.isdigit():
                            newstr=newstr+str(int(j)+1)
                        else:
                            newstr=newstr+j
                    wx.Window.FindWindowById(self.testid[i]).SetValue(newstr)            
        temdata=[]
        for i in range(96):
            temdata.append(wx.Window.FindWindowById(self.testid[i]).GetValue())
        tempath=os.path.dirname(os.path.abspath(__file__)) + r"\data\tem\tem.txt"
        temtxt=open(tempath,"w")
        temtxt.write("listname::" + self.testname.GetValue()+"\n")
        for i in temdata:
            temtxt.write(i+"\n")
        temtxt.close()
        uliquedata=[temdata[0]]
        samedata=0
        for i in temdata[1:]:
            if samedata==1:
                break
            for j in uliquedata:
                if i == j and i!="" :
                    samedata=1
                    wx.MessageDialog(None,'Duplicate sample name:' + i,"Warning",wx.OK).ShowModal()
                    break
            if samedata==0:
                uliquedata.append(i)
        if self.testname.GetValue():
            filename=self.testname.GetValue() 
            filedir=os.path.dirname(os.path.abspath(__file__)) + "\\data\\"
            filetxt=open(filedir+filename+".txt","w")
            filetxt.write("listname::" + filename+"\n")
            for i in range(96):
                filetxt.write(wx.Window.FindWindowById(self.testid[i]).GetValue() + "\n")
            filetxt.close()
        else:
            dial=wx.MessageDialog(None,'List name cannot be empty',"Warning",wx.OK)
            dial.ShowModal()
    def getpos(self,evt):
        temid=evt.GetId()
        temtextctrlid=0
        for i in range(5):
            if self.clickid[i]==temid:  
                temtextctrlid=self.clickposid[i]    
                x,y = pyautogui.position()
                wx.FindWindowById(temtextctrlid).SetValue( str(x) + "," + str(y))
    def evtsavepos(self,evt):
        temdata=[]
        for i in range(5):
            temdata.append(wx.Window.FindWindowById(self.clickposid[i]).GetValue())
        temfile=self.postxtpath=os.path.dirname(os.path.abspath(__file__)) + "\\setting\\possetting.txt"
        temfile=open(temfile,"w")
        for i in range(5):
            temfile.write(temdata[i]+"\n")
        temfile.close()
    def evtautoclick(self,evt):
        pos=[]
        pos96=[]    
        for i in self.clickposid:
            pos.append(wx.Window.FindWindowById(i).GetValue())  
        for i in range(5):
            temx,temy=pos[i].split(",")
            temx=float(temx)
            temy=float(temy)
            pos[i]=(temx,temy)    
        oringex=pos[1][0]
        oringey=pos[1][1]
        finalx=pos[4][0]
        finaly=pos[4][1]
        addx=(float(finalx)-float(oringex))/11.0
        addy=(float(finaly)-float(oringey))/7.0
        for i in range(12):
            for j in range(8):
                pos96.append((oringex+i*addx,oringey+j*addy))   
        pyautogui.click(x=float(pos[0][0]), y=float(pos[0][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
        time.sleep(float(self.tclinterval.GetValue()))
        for i in range(96):
            pyautogui.click(x=float(pos96[i][0]), y=float(pos96[i][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
            time.sleep(float(self.tclinterval.GetValue()))
            pyautogui.click(x=float(pos[2][0]), y=float(pos[2][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
            time.sleep(float(self.tclinterval.GetValue()))
            pyautogui.click(x=float(pos[3][0]), y=float(pos[3][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
            time.sleep(float(self.tclinterval.GetValue()))
    def evttextchange(self,evt):
        self.bollhaveautofilled=False
    def evtonekeyinput(self,evt):
        if self.bollhaveautofilled==True:
            self.evtautotype(self)
            self.evtautoclick(self)
        else:
            wx.MessageDialog(None,"Please 'Auto-Fullfill' First","Warning",wx.OK).ShowModal()
        
app=wx.App()
frame=fra()
frame.Show()
app.MainLoop()
