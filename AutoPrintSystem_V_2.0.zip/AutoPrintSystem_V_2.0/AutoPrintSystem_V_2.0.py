import wx
import wx.grid
import os
import time
import pyautogui
class fra(wx.Frame):
    def __init__(self):
        #get temdata
        self.temfile=os.getcwd() + r"\data\tem\tem.txt" #tem path
        self.pospath=os.getcwd() + r"\setting\possetting.txt"
        self.savefolder=os.getcwd() + r"\data"
        temtxt=open(self.temfile,"r")
        temdata=temtxt.readlines()
        temtxt.close()
        temtitle=temdata[0][10:].strip("\n")    #get title
        temtestnum=[]
        for i in temdata[1:]:
            temtestnum.append(i.strip("\n"))
        while len(temtestnum)<96:
            temtestnum.append("")   #get testnum

        #get pos data
        temtxt=open(self.pospath,"r")
        self.posdata=temtxt.readlines()
        for i in range(len(self.posdata)):
            self.posdata[i]=self.posdata[i].strip("\n")

        #Global Variable
        self.saved=0
        
        #Set special word
        self.spstr=["NC1","NC2","NC3","PC","BK","NONE"]

        #construct frame
        wx.Frame.__init__(self,None,-1,title="Auto-Print System V2.0",size=(800,600),pos=(0,0))
        panel=wx.Panel(self)
        self.tecinterval=wx.TextCtrl(panel,id=-1,value="0.1",pos=(720,185),size=(40,30))

        #construct title
        wx.StaticText(panel,id=-1,pos=(10,10),label="List Name:")
        self.tetctitle=wx.TextCtrl(panel,id=-1,pos=(75,10),size=(100,20),value=temtitle)    #title

        #construct Buttons
        wx.Button(panel,-1, label="Clear" , pos=(650,25) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtclear)
        wx.Button(panel,-1, label="QC" , pos=(650,65) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtqc)
        wx.Button(panel,-1, label="AutoFill" , pos=(650,105) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtautofill)
        wx.Button(panel,-1, label="Save" , pos=(650,145) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtsave)
        wx.StaticText(panel,id=-1,pos=(650,185),label="Interval:")
        wx.Button(panel,-1, label="AutoPrint" , pos=(650,225) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtautoprint)
        wx.Button(panel,-1, label="AutoClick" , pos=(650,265) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtautoclick)
        wx.Button(panel,-1, label="OneKeyInput" , pos=(650,305) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtonekeyinput)
        wx.Button(panel,-1, label="Import" , pos=(0,300) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtimp)
        wx.Button(panel,-1, label="Developer" , pos=(0,340) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtdeve)
        wx.Button(panel,-1, label="Result" , pos=(0,380) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtresult)

        
        #Construct a grid which contains all testnum and initialize it 
        self.grid=wx.grid.Grid(panel,-1,size=(620,260),pos=(0,30))
        self.grid.SetDefaultColSize(75)
        self.grid.SetDefaultRowSize(20)
        self.grid.CreateGrid(12,8)
        self.grid.SetColLabelSize(15)
        self.grid.SetRowLabelSize(20)
        self.grid.SetTabBehaviour(wx.grid.Grid.TabBehaviour.Tab_Wrap)
        self.grid.DisableDragGridSize()
        self.grid.DisableDragColSize()
        self.grid.DisableDragRowSize()
        self.grid.Bind(wx.grid.EVT_GRID_CELL_CHANGED,self.changing)
        for i in range(12):
            for j in range(8):
                self.grid.SetCellValue (i,j,temtestnum[8*i+j])
                
    def evtsave(self,evt):
        title=self.tetctitle.GetValue()
        data=[]
        if title=="":
            wx.MessageDialog(None,'Please input title' ,"Warning",wx.OK).ShowModal()
        else:
            for i in range(12):
                for j in range(8):
                    data.append(self.grid.GetCellValue (i,j))
            temtxt=open(self.temfile,"w")
            temtxt.write("listname::" + title + "\n")
            for i in data:
                temtxt.write(i + "\n")
            temtxt.close()
            savetxt=open(self.savefolder + title + ".txt","w")
            savetxt.write("listname::" + title + "\n")
            for i in data:
                savetxt.write(i + "\n")
            temtxt.close()
            self.saved=1
            wx.MessageDialog(None,'Save Successfully' ," ",wx.OK).ShowModal()
        
    def evtqc(self,evt):
        for j in range(4):
            self.grid.SetCellValue(0,j,self.spstr[j])
        self.grid.SetCellValue(11,7,"BK")

    def evtclear(self,evt):
        self.grid.ClearGrid()
        
    def evtautofill(self,evt):
        data=[]
        for i in range(12):
            for j in range(8):
                data.append(self.grid.GetCellValue(i,j))
        for i in range(96):
            if data[i]=="":
                if i == 0:
                    data[i]="NONE"
                else:
                    if data[i-1].isdigit():
                        data[i]=str(int(data[i-1])+1)
                    elif data[i-1] in self.spstr:
                        data[i]="NONE"
                    else:
                        change=0
                        ini=0
                        for j in range(len(data[i-1])-1):
                            if data[i-1][j].isdigit() != data[i-1][j+1].isdigit():
                                change+=1
                        if change==1:
                            if data[i-1][0].isdigit():
                                ini=1
                        if change>1 or ini==1:
                            wx.MessageDialog(None,'Please input testnum in right format' ,"Warning",wx.OK).ShowModal()
                            if (i+1)%8 ==0:
                                temrow=(i+1)/8-1
                                temcol=7
                            else:
                                temrow=int((i+1)/8)
                                temcol=(i+1)%8-1
                            self.grid.SetGridCursor (temrow,temcol)
                            break
                        else:
                            for j in range(len(data[i-1])-1):
                                if data[i-1][j].isdigit() != data[i-1][j+1].isdigit():
                                    break
                            data[i]=data[i-1][:(j+1)] + str(int(data[i-1][j+1:])+1)
         
        for i in range(12):
            for j in range(8):
                self.grid.SetCellValue(i,j,data[8*i+j].upper())
        if self.findsame()==False:
            self.saved=1
            self.evtsave(evt)
            
    def evtautoprint(self,evt):
        data=[]
        if self.saved==1:
            for i in range(12):
                for j in range(8):
                    data.append(self.grid.GetCellValue(i,j))
            time.sleep(3)
            for i in data:
                if i!="NONE":
                    pyautogui.typewrite(message=i,interval=0.01)
                    time.sleep(float(self.tecinterval.GetValue()))
                    pyautogui.press('down')
                    time.sleep(float(self.tecinterval.GetValue()))                                          
        else:
            wx.MessageDialog(None,'Please save first' ,"Warning",wx.OK).ShowModal()
            
    def changing(self,evt):
        self.saved=0
        contain=self.grid.GetCellValue(evt.GetRow(),evt.GetCol()).upper()
        self.grid.SetCellValue(evt.GetRow(),evt.GetCol(),contain)
        
    def evtdeve(self,evt):
        class fradve(wx.Frame):
            def __init__(self,parent,savepath):
                wx.Frame.__init__(self,parent,-1,title="Developer Options",size=(325,290),style=wx.FRAME_FLOAT_ON_PARENT|wx.DEFAULT_FRAME_STYLE)
                panel=wx.Panel(self)
                wx.Button(panel,-1, label="Save" , pos=(200,0) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtsave)
                self.butid=[]
                self.staid=[]
                self.savepath=savepath
                temtxt=open(self.savepath,"r")
                line=temtxt.readlines()
                temtxt.close()
                temdata=[]
                for i in line:
                    temdata.append(i.strip("\n"))
                
                #pos
                for i in range(6):
                    #Set Button
                    temid=wx.NewId()
                    self.butid.append(temid)
                    wx.Button(panel,temid, label="C"+str(i+1) , pos=(0,40*i) , size= (100,40)).Bind(wx.EVT_BUTTON,self.click)
                    
                    #Set text
                    temid=wx.NewId()
                    self.staid.append(temid)
                    wx.StaticText(panel,id=temid,pos=(100,10+40*i),label=temdata[i])
            def click(self,evt):
                x,y = pyautogui.position()
                temid=self.staid[self.butid.index(evt.GetId())]
                wx.FindWindowById(temid).SetLabel(str(x)+","+str(y))
            def evtsave(self,evt):
                posdata=[]
                for i in self.staid:
                    posdata.append(wx.FindWindowById(i).GetLabel())
                temtxt=open(self.savepath,"w")
                for i in posdata:
                    temtxt.write(i+"\n")
                temtxt.close()
                wx.MessageDialog(None,'Save Successfully' ," ",wx.OK).ShowModal()
                
        fradve=fradve(self,self.pospath)
        fradve.Show()
    
    def evtimp(self,evt):
        dlg=wx.FileDialog(None,message="Choose a TXT",
                         defaultDir=self.savefolder,
                         wildcard="txt files(*.txt)|*.txt")
        if dlg.ShowModal()==wx.ID_OK:
            tempath=dlg.GetPath()
            temfile=open (tempath,"r")
            txtdata=temfile.readlines()
            temfile.close()
            if "listname::" in txtdata[0]:
                temtitle=txtdata[0][10:]
                self.tetctitle.SetValue(temtitle)
                data=[]
                for i in range(12):
                    for j in range(8):
                        self.grid.SetCellValue(i,j,txtdata[8*i+j+1].strip("\n"))
            else:
                wx.MessageDialog(None,'Please choose a right txt file' ,"Warning",wx.OK).ShowModal()
        dlg.Destroy()
        
    def findsame(self):
        data=[]
        temdata=[]
        same=False
        for i in range(12):
            for j in range(8):
                data.append(self.grid.GetCellValue(i,j))
        temdata.append(data[0])
        for i in data[1:]:
            if i in temdata:
                if i== "NONE":
                    continue
                else:
                    same=True
                    wx.MessageDialog(None,'Duplicate testnum:' + i ,"Warning",wx.OK).ShowModal()
                    break
            else:
                temdata.append(i)
        return same
    def evtautoclick(self,evt):
        temdata=[]
        tempos=[]
        pos96=[]
        interval=float(self.tecinterval.GetValue())
        for i in range(12):
            for j in range(8):
                temdata.append(self.grid.GetCellValue(i,j))
        temtxt=open(self.pospath,"r")
        line=temtxt.readlines()
        temtxt.close()
        
        #pos96 index:1,4,Get all 96 pos
        for i in line:
            tempos.append(i.strip("\n").split(","))
        opos=[tempos[1][0],tempos[1][1]]
        xadd=(float(tempos[4][0])-float(tempos[1][0]))/11.0
        yadd=(float(tempos[4][1])-float(tempos[1][1]))/7.0
        for i in range(12):
            for j in range(8):
                pos96.append((float(opos[0])+i*xadd,float(opos[1])+j*yadd))
        time.sleep(interval)
        pyautogui.click(x=float(tempos[0][0]), y=float(tempos[0][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
        time.sleep(interval)
        pyautogui.mouseDown(x=float(tempos[5][0]), y=float(tempos[5][1]), button='left')
        time.sleep(interval)
        pyautogui.mouseUp(x=float(tempos[5][0])+230, y=float(tempos[5][1]), button='left')
        time.sleep(interval)
        for i in range(96):
            if temdata[i]!="NONE":
                pyautogui.click(x=float(pos96[i][0]), y=float(pos96[i][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
                time.sleep(interval)
                pyautogui.click(x=float(tempos[2][0]), y=float(tempos[2][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
                time.sleep(interval)
                pyautogui.click(x=float(tempos[3][0]), y=float(tempos[3][1]), clicks=1, interval=0.1, button='left', duration=0.0, tween=pyautogui.linear)
                time.sleep(interval)
                
    def evtonekeyinput(self,evt):
        self.evtautoprint(evt)
        self.evtautoclick(evt)

    def evtresult(self,evt):
        dlg=wx.FileDialog(None,message="Choose a TXT",
                         defaultDir=self.savefolder,
                         wildcard="txt files(*.txt)|*.txt")
        if dlg.ShowModal()==wx.ID_OK:
            tempath=dlg.GetPath()
            temtxt=open(tempath,"r")
            line=temtxt.readlines()
            temtxt.close()
            if "listname::" in line[0]:
                temdata=[]
                for i in line[1:]:
                    if not(i.strip("\n") in self.spstr):
                        temdata.append(i.strip("\n"))
                rownum=len(temdata)
                title=line[0][10:].strip("\n")
                class fraresult(wx.Frame):
                    def __init__(self,parent,rownum,title):
                        wx.Frame.__init__(self,parent,-1,title="Result Solving",size=(450,600),style=wx.FRAME_FLOAT_ON_PARENT|wx.DEFAULT_FRAME_STYLE)
                        panel=wx.Panel(self)

                        #global variable
                        self.saved=False

                        #construct title
                        wx.StaticText(panel,id=-1,pos=(10,10),label="List Name:")
                        self.tetctitle=wx.TextCtrl(panel,id=-1,pos=(75,10),size=(100,20),value=title)

                        #construct button
                        wx.Button(panel,-1, label="NegtiveFill" , pos=(300,50) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtautofill)
                        prefix=["XG","ZB","XGTJ"]
                        for i in range(3):
                            wx.Button(panel,-1, label=prefix[i] , pos=(200,50+i*40) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtprefix)
                        wx.Button(panel,-1, label="Result View" , pos=(200,250) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtresultview)
                        wx.Button(panel,-1, label="Save" , pos=(300,250) , size= (100,40)).Bind(wx.EVT_BUTTON,self.evtsave)
                        
                        #construct grid
                        self.grid=wx.grid.Grid(panel,-1,size=(200,500),pos=(0,30))
                        self.grid.CreateGrid(rownum,2)
                        self.grid.SetDefaultColSize(75)
                        self.grid.SetDefaultRowSize(20)
                        self.grid.SetColLabelSize(15)
                        self.grid.SetRowLabelSize(20)
                        self.grid.SetColLabelValue(0,"TestNum")
                        self.grid.SetColLabelValue(1,"Result")
                        self.grid.DisableDragGridSize()
                        self.grid.DisableDragColSize()
                        self.grid.DisableDragRowSize()

                        #bind evt
                        self.grid.SetTabBehaviour(wx.grid.Grid.TabBehaviour.Tab_Wrap)
                        self.grid.Bind(wx.grid.EVT_GRID_CELL_CHANGED,self.evtstan)
                        self.Bind(wx.EVT_CLOSE,self.evtOnClose)

                        #input data
                        for i in range(len(temdata)):
                            self.grid.SetCellValue(i,0,temdata[i])
                    def evtstan(self,evt):
                        self.saved=False
                        if evt.GetCol()==1:
                            dicstan={"1":"Negtive","2":"Via","3":"One Target","4":"Two Targets"}
                            col=evt.GetCol()
                            row=evt.GetRow()
                            temval=self.grid.GetCellValue(row,col)
                            if temval in dicstan:
                                self.grid.SetCellValue(row,col,dicstan[temval])
                            elif temval in dicstan.values():
                                pass
                            else:
                                self.grid.SetCellValue(row,col,"")
                                
                    def evtautofill(self,evt):
                        self.saved=False
                        rownum=self.grid.GetNumberRows()
                        for i in range(rownum):
                            if self.grid.GetCellValue(i,1)=="":
                                self.grid.SetCellValue(i,1,"Negtive")
                                
                    def evtprefix(self,evt):
                        self.saved=False
                        rownum=self.grid.GetNumberRows()
                        prefix=wx.FindWindowById(evt.GetId()).GetLabel()
                        for i in range(rownum):
                            temval=self.grid.GetCellValue(i,0)
                            if temval[:2]=="XG" or temval[:2]=="ZB" or temval[:4]=="XGTJ":
                                pass
                            else:
                                self.grid.SetCellValue(i,0,prefix + temval)
                    def evtsave(self,evt):
                        title=self.tetctitle.GetValue()
                        path=os.getcwd()+r"\result" + "\\" + title + ".txt"
                        data=[]
                        rownum=self.grid.GetNumberRows()
                        warn=False
                        for i in range(rownum):
                            if self.grid.GetCellValue(i,0)!="" and self.grid.GetCellValue(i,1) != "":
                                data.append([self.grid.GetCellValue(i,0),self.grid.GetCellValue(i,1)])
                                temtxt=open(path,"w")
                                temtxt.write("Result\nlistname:" + title + "\n")
                                for i in range(len(data)):
                                    temtxt.write(data[i][0]+chr(9)+data[i][1]+"\n")
                                temtxt.close()
                            else:
                                wx.MessageDialog(None,'Please input all of Testnum and Result' ,"Warning",wx.OK).ShowModal()
                                warn=True
                                break
                        if warn==False:
                            self.saved=True
                            dlg=wx.MessageDialog(None,'Save Successfully' ," ",wx.OK).ShowModal()
                            dlg.Destroy()
                    def evtresultview(self,evt):
                        if self.saved:
                            resultpath=os.getcwd() + r"\result"
                            dlg=wx.FileDialog(None,message="Choose a TXT",
                                             defaultDir=resultpath,
                                             wildcard="txt files(*.txt)|*.txt")
                            if dlg.ShowModal()==wx.ID_OK:
                                tempath=dlg.GetPath()
                                dlg.Destroy()
                                temtxt=open(tempath,"r")
                                line=temtxt.readlines()
                                temtxt.close()
                                if line[0].strip("\n")=="Result":
                                    title=line[1][9:].strip("\n")
                                    self.tetctitle.SetValue(title)
                                    data=[]
                                    for i in line[2:]:
                                        data.append(i.strip("\n").split(chr(9)))
                                    rownum=len(data)
                                    self.grid.ClearGrid()
                                    if rownum>self.grid.GetNumberRows():
                                        self.grid.AppendRows(numRows=rownum-self.grid.GetNumberRows())
                                    elif rownum<self.grid.GetNumberRows():
                                        self.grid.DeleteRows(numRows=self.grid.GetNumberRows()-rownum)
                                    else:
                                        pass
                                    for i in range(rownum):
                                        self.grid.SetCellValue(i,0,data[i][0])
                                        self.grid.SetCellValue(i,1,data[i][1])
                                else:
                                    wx.MessageDialog(None,'Please choose a right txt' ,"Warning",wx.OK).ShowModal()
                        else:
                            dlg=wx.MessageDialog(None,
                                             "You haven't saved the results\nDo you want to save the results first? ",
                                             "MessageBoxCaptionStr",style=wx.YES_NO|wx.CANCEL)
                            modal=dlg.ShowModal()
                            dlg.Destroy()
                            if modal==wx.ID_YES:
                                self.evtsave(evt)
                            elif modal==wx.ID_NO:
                                self.saved=True
                                self.evtresultview(evt)
                            elif modal==wx.ID_CANCEL:
                                pass
                    def evtOnClose(self,evt):
                        if not self.saved:
                            if wx.MessageBox("You haven't saved the results\nDo you want to save the results first? ",
                                             "Please confirm",
                                             wx.ICON_QUESTION | wx.YES_NO) != wx.NO:
                                return
                        self.Destroy()
                            
                fraresult=fraresult(self,rownum,title)
                fraresult.Show()
            else:
                wx.MessageDialog(None,'Please choose a right txt',"Warning",wx.OK).ShowModal()
           
if __name__=="__main__":
    app=wx.App()
    fra=fra()
    fra.Show()
    app.MainLoop()
